Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "cmd /c start """" """ & Replace(WScript.ScriptFullName, WScript.ScriptName, "") & "SSN-Attendance.html""", 0, False
