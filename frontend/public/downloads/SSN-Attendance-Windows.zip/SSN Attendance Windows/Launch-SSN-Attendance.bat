@echo off
title SSN IT Attendance System
start "" "%~dp0SSN-Attendance.html"
exit
