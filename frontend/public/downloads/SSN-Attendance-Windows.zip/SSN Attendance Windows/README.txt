=====================================================
SSN IT ATTENDANCE TRACKING SYSTEM — WINDOWS EDITION
=====================================================

HOW TO USE:
1. Double-click "SSN-Attendance.vbs" or "Launch-SSN-Attendance.bat" to start.
2. The attendance tracking portal will open immediately in your default browser.
3. Works completely offline with zero installation required.

SSN College of Engineering • Department of Information Technology
